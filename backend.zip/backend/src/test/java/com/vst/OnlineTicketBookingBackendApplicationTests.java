package com.vst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineTicketBookingBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
